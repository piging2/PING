/**
 * Jest config for the TenantOS substrate lane. Scoped to this lane's tests
 * only. Run with: npx jest --config src/tenanos/jest.config.cjs
 * Shape harvested from src/fyd/jest.config.cjs.
 */
module.exports = {
  testEnvironment: "node",
  rootDir: "../..",
  testMatch: ["<rootDir>/src/tenanos/__tests__/*.test.ts"],
  moduleNameMapper: {
    "^@/(.*)$": "<rootDir>/src/$1",
  },
  transform: {
    "^.+\\.tsx?$": [
      "ts-jest",
      {
        tsconfig: {
          target: "ES2017",
          module: "commonjs",
          moduleResolution: "node",
          jsx: "react-jsx",
          esModuleInterop: true,
          strict: true,
          skipLibCheck: true,
        },
      },
    ],
  },
};
