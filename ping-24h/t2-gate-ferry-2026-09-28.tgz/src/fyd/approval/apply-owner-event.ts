/**
 * Phase 1 approval door: default object-transition adapter.
 *
 * Reuses the EXISTING durable owner-transition path
 * (src/fyd/object/owner-events.ts): an approved fact_correction becomes one
 * appended owner event (owner.corrected-fact / owner.confirmed-fact /
 * owner.restored-fact), and the owner-visible state is the pure fold
 * projectOwnerState(objectId). This file adds no new write path; it only
 * translates the gate's typed transition request into the existing event
 * draft shape.
 *
 * Scope note: the gate's default adapter covers owner contact-field
 * corrections (phone/email/website), the only field targets the
 * owner-events reducer accepts for corrected-fact. Anything else fails
 * closed with GateTransitionError and the gate converts it to a DENIED
 * decision (reason 'target-unresolvable'), never an apply.
 *
 * Server-only (node:fs via owner-events.ts). No wall clock: timestamps
 * derive from the injected decidedAtMs.
 */

import {
  appendOwnerEvent,
  projectOwnerState,
  FYD_OWNER_GENERATOR,
  type OwnerEventDraft,
} from "../object/owner-events";

/** Contact fields the owner-events reducer accepts for corrected-fact. */
export type GateCorrectableField = "phone" | "email" | "website";

/** Owner ops the gate can authorize on a contact field. */
export type GateCorrectionOp = "CONFIRM" | "CORRECT" | "RESTORE";

const FIELD_LABEL: Record<GateCorrectableField, string> = {
  phone: "Phone",
  email: "Email",
  website: "Website",
};

const OBJECT_ID_RE = /^[a-z0-9-]+$/;

/** The typed transition the gate authorizes, carried inside proposal.patch. */
export interface GatePatchTransition {
  kind: "fact_correction";
  objectId: string;
  field: GateCorrectableField;
  op: GateCorrectionOp;
  value: string | null;
  sourceValueSeen: string | null;
}

export interface GateTransitionRequest {
  proposalId: string;
  proposedDigest: string;
  targetObjectId: string;
  /** The exact proposal bytes whose digest was verified (proposal.patch). */
  patch: unknown;
  evidenceRefs: string[];
}

export interface GateTransitionContext {
  deciderIdentity: string;
  /** Injected clock (ms); the event's `at` derives from this. */
  decidedAtMs: number;
}

export class GateTransitionError extends Error {
  readonly code: "target-unresolvable" | "transition-malformed";
  constructor(
    code: "target-unresolvable" | "transition-malformed",
    message: string,
  ) {
    super("gate-transition[" + code + "]: " + message);
    this.name = "GateTransitionError";
    this.code = code;
  }
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

function isGateField(v: unknown): v is GateCorrectableField {
  return v === "phone" || v === "email" || v === "website";
}

function isGateOp(v: unknown): v is GateCorrectionOp {
  return v === "CONFIRM" || v === "CORRECT" || v === "RESTORE";
}

/**
 * Validate the patch's transition payload and bind it to the proposal's
 * target object. Throws GateTransitionError on anything unresolvable;
 * the gate converts this to DENIED ('target-unresolvable') with zero
 * mutation. Runs BEFORE any effect, so validation can never half-apply.
 */
export function resolveGateTransitionTarget(
  patch: unknown,
  targetObjectId: string,
): GatePatchTransition {
  if (typeof targetObjectId !== "string" || !OBJECT_ID_RE.test(targetObjectId)) {
    throw new GateTransitionError(
      "target-unresolvable",
      "target_object_id is not a valid owner-store object id.",
    );
  }
  if (!isRecord(patch)) {
    throw new GateTransitionError(
      "transition-malformed",
      "proposal.patch is not an object.",
    );
  }
  if (patch.kind !== "fact_correction") {
    throw new GateTransitionError(
      "transition-malformed",
      "unsupported patch kind '" + String(patch.kind) + "'; gate handles fact_correction only.",
    );
  }
  if (typeof patch.objectId !== "string" || patch.objectId !== targetObjectId) {
    throw new GateTransitionError(
      "target-unresolvable",
      "patch.objectId does not match the proposal target_object_id.",
    );
  }
  if (!isGateField(patch.field)) {
    throw new GateTransitionError(
      "target-unresolvable",
      "field '" + String(patch.field) + "' is not a gate-correctable contact field (phone/email/website).",
    );
  }
  if (!isGateOp(patch.op)) {
    throw new GateTransitionError(
      "transition-malformed",
      "op '" + String(patch.op) + "' is not a gate-supported correction op.",
    );
  }
  let value: string | null = null;
  if (patch.op === "CORRECT") {
    if (typeof patch.value !== "string" || patch.value.trim().length === 0) {
      throw new GateTransitionError(
        "transition-malformed",
        "CORRECT requires a non-empty string value.",
      );
    }
    if (patch.value.length > 2000) {
      throw new GateTransitionError(
        "transition-malformed",
        "CORRECT value exceeds 2000 characters.",
      );
    }
    value = patch.value;
  } else if (
    patch.value !== undefined &&
    patch.value !== null &&
    patch.value !== ""
  ) {
    throw new GateTransitionError(
      "transition-malformed",
      "op " + patch.op + " does not take a value.",
    );
  }
  const sourceValueSeen =
    typeof patch.sourceValueSeen === "string" ? patch.sourceValueSeen : null;
  return {
    kind: "fact_correction",
    objectId: targetObjectId,
    field: patch.field,
    op: patch.op,
    value,
    sourceValueSeen,
  };
}

/** Canonical owner-visible state bytes source for pre/post hashes. */
export function readGateObjectState(objectId: string): unknown {
  return projectOwnerState(objectId);
}

function contactTarget(field: GateCorrectableField): string {
  return "contact:" + field;
}

function toOwnerEventDraft(
  t: GatePatchTransition,
  req: GateTransitionRequest,
  ctx: GateTransitionContext,
): OwnerEventDraft {
  const at = new Date(ctx.decidedAtMs).toISOString();
  const actor = {
    kind: "owner" as const,
    identityId: ctx.deciderIdentity,
    label: ctx.deciderIdentity,
  };
  const evidence = {
    kind: "owner-approval",
    ref: "approval:" + req.proposalId,
    detail:
      "evidence_refs: " + req.evidenceRefs.join(", ") +
      "; proposed_digest: " + req.proposedDigest,
  };
  // Honest previousBasis: the owner-visible value before this transition.
  const before = projectOwnerState(t.objectId);
  const priorCorrection =
    before.fieldCorrections?.[t.field] as
      | { ownerValue?: unknown; sourceValue?: unknown }
      | undefined;
  const previousBasis =
    priorCorrection && typeof priorCorrection.ownerValue === "string"
      ? {
          ownerValue: priorCorrection.ownerValue,
          sourceValue:
            typeof priorCorrection.sourceValue === "string"
              ? priorCorrection.sourceValue
              : null,
        }
      : null;

  if (t.op === "CORRECT") {
    const ownerValue = t.value as string;
    return {
      at,
      objectId: t.objectId,
      type: "owner.corrected-fact",
      actor,
      target: contactTarget(t.field),
      previousBasis,
      newValue: {
        field: t.field,
        label: FIELD_LABEL[t.field],
        sourceValue: t.sourceValueSeen,
        ownerValue,
        correctedAt: at,
        actorLabel: ctx.deciderIdentity,
        basis:
          "Owner correction via approval gate " + req.proposalId +
          ": the owner says " + FIELD_LABEL[t.field] + " is '" + ownerValue + "'.",
      },
      evidence,
      note:
        "Approval gate " + req.proposalId + ": owner corrected " +
        FIELD_LABEL[t.field] + " to '" + ownerValue + "'.",
      generator: FYD_OWNER_GENERATOR,
    };
  }
  if (t.op === "CONFIRM") {
    return {
      at,
      objectId: t.objectId,
      type: "owner.confirmed-fact",
      actor,
      target: contactTarget(t.field),
      previousBasis,
      newValue: {
        confirmation: true,
        confirmedValue: t.value ?? t.sourceValueSeen,
        sourceValue: t.sourceValueSeen,
        actorLabel: ctx.deciderIdentity,
      },
      evidence,
      note:
        "Approval gate " + req.proposalId + ": owner confirmed " +
        FIELD_LABEL[t.field] + ".",
      generator: FYD_OWNER_GENERATOR,
    };
  }
  // RESTORE: revert is a new event, never a delete; the correction event
  // stays in the log and the projection stops composing it.
  return {
    at,
    objectId: t.objectId,
    type: "owner.restored-fact",
    actor,
    target: contactTarget(t.field),
    previousBasis,
    newValue: null,
    evidence,
    note:
      "Approval gate " + req.proposalId + ": owner reverted the " +
      FIELD_LABEL[t.field] + " correction.",
    generator: FYD_OWNER_GENERATOR,
  };
}

/**
 * Apply one gate-authorized transition through the existing owner event
 * log. Appends exactly one event; the store write is atomic (tmp+rename
 * inside appendOwnerEvent). Throws GateTransitionError on unresolvable
 * targets (gate converts to DENIED) or OwnerEventError on store failure
 * (loud, no APPROVED journal, operator-visible).
 */
export function applyGateTransition(
  req: GateTransitionRequest,
  ctx: GateTransitionContext,
): void {
  const t = resolveGateTransitionTarget(req.patch, req.targetObjectId);
  appendOwnerEvent(t.objectId, toOwnerEventDraft(t, req, ctx));
}
