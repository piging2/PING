/**
 * Phase 1 approval door: the owner decision gate.
 *
 * The human-authority seam: INTENT -> PROPOSAL BYTES -> PROPOSAL DIGEST ->
 * EVIDENCE -> PREVIEW -> OWNER DECISION -> EXACT-DIGEST VERIFICATION ->
 * AUTHORIZED TRANSITION -> CANONICAL EVENT -> OBJECT CHANGE -> DEPENDENT
 * PROJECTIONS. This file is the EXACT-DIGEST VERIFICATION and AUTHORIZED
 * TRANSITION step. It owns no proposal queue, no journal store, and no
 * object write path; it only decides, in a fixed verification order, with
 * authorization strictly BEFORE effect.
 *
 * Verification order on APPROVE (all before effect):
 *   0. not terminal  (status PROPOSED only; else ALREADY_DECIDED, no
 *                     journal, no mutation. Evaluated FIRST: a terminal
 *                     lifecycle is immutable, so no second decision may
 *                     rewrite it even if its checks would fail.)
 *   1. identity      (deciderIdentity present and well-formed; fail-closed)
 *   2. capability    (deciderCapabilities includes proposal.required_capability)
 *   3. exact digest  (sha256(canonical(proposal.patch)) === proposal.proposed_digest)
 *   4. base state    (sha256(canonical(sourceBytesNow)) === proposal.base_digest;
 *                     mismatch => STALE_SUPERSEDED, the TOCTOU guard)
 *   5. not expired   (nowMs > expires_at => EXPIRED, reject-by-default;
 *                     also evaluated before DENY effects so an expired
 *                     proposal is never "denied", only EXPIRED)
 *   6. target        (target_object_id resolves to an appliable transition)
 *   7. evidence      (evidence_refs meet the proposal's requirements)
 *   8. transition    (apply via the existing owner-events path; pre/post
 *                     hashes over canonical object bytes; mark APPROVED;
 *                     journal APPROVAL_APPROVED)
 *
 * Fail-closed throughout: a missing digest, an unbound source, a stale
 * base, an expired gate, an unresolvable target, missing evidence, or a
 * missing capability is a DENY (or the typed STALE_SUPERSEDED / EXPIRED),
 * never an apply. Approval of proposal X MUST NOT authorize a modified X:
 * one byte changes, the digest changes, the old approval is invalid.
 *
 * Clock: injectable nowMs only. No Date.now(), no new Date() except as a
 * pure function of nowMs. Deterministic given (queue, journal, nowMs).
 *
 * Server-only.
 */

import { createHash } from "node:crypto";
import { canonicalizeJson } from "../../lib/ping/dev-signer";
import { getProposal, markProposal } from "./queue";
import { appendApprovalEvent } from "./journal";
import type {
  DigestBoundProposal,
  ProposalStatus,
  ApprovalEventType,
} from "./types";
import {
  applyGateTransition,
  readGateObjectState,
  resolveGateTransitionTarget,
  GateTransitionError,
  type GateTransitionRequest,
  type GateTransitionContext,
} from "./apply-owner-event";

/* ------------------------------------------------------------------ */
/* Teammate-file contracts (T1 queue/types, T3 journal).                */
/*                                                                     */
/* The imports above bind to T1's ./queue + ./types and T3's ./journal,*/
/* which are not present yet. The expected signatures are declared     */
/* here; reconcile against the real files when they land. This file    */
/* does NOT define competing queue/journal/types modules.             */
/*                                                                     */
/* ./queue:                                                            */
/*   getProposal(proposal_id: string): DigestBoundProposal | undefined  */
/*   markProposal(proposal_id: string, status: ProposalStatus,          */
/*                decided_at_ms: number, decided_by: string): void      */
/* ./journal:                                                          */
/*   appendApprovalEvent(journalPath: string,                           */
/*     event: ApprovalJournalPayload): string  // returns journal event */
/*     id; the journal owns id generation, payload-in/id-out, same     */
/*     pattern as the existing appendOwnerEvent.                       */
/* ./types:                                                            */
/*   DigestBoundProposal: the assumed shape below.                      */
/* ------------------------------------------------------------------ */

/**
 * ASSUMED shape of T1's DigestBoundProposal (./types). Every field the
 * gate reads is validated at runtime before use; reconcile field names
 * with T1's file when it lands.
 *
 *   proposal_id: string            stable proposal identity
 *   status: ProposalStatus         'PROPOSED' | 'APPROVED' | 'DENIED' |
 *                                  'EXPIRED' | 'SUPERSEDED'
 *   patch: unknown                 the EXACT proposal bytes; the digest
 *                                  binds these and nothing else
 *   proposed_digest: string        sha256(canonical(patch)) at draft time
 *   base_digest: string            sha256 of the source bytes the proposal
 *                                  was drafted against (TOCTOU anchor)
 *   required_capability: string    capability the decider must hold
 *   target_object_id: string       BUSINESS object the transition targets
 *   evidence_refs: string[]        evidence backing the proposal
 *   min_evidence_refs?: number     required evidence count (default 1)
 *   expires_at: number             decision deadline, ms since epoch
 */
export type ProposalRecord = DigestBoundProposal;

export type ApprovalVerdict = "APPROVE" | "DENY";

export type ApprovalOutcome =
  | "APPLIED"
  | "DENIED"
  | "EXPIRED"
  | "STALE_SUPERSEDED"
  | "ALREADY_DECIDED";

export interface ApprovalContext {
  sourceBytesNow: string;
  deciderIdentity: string;
  deciderCapabilities: string[];
  journalPath: string;
}

export interface ApprovalResult {
  outcome: ApprovalOutcome;
  preHash: string | null;
  postHash: string | null;
  journalEventId: string;
  reason?: string;
}

/** System identity recorded for gate-owned lifecycle moves (no owner). */
const GATE_SYSTEM_IDENTITY = "approval-gate";

const TERMINAL_STATUSES: ProposalStatus[] = [
  "APPROVED",
  "DENIED",
  "EXPIRED",
  "SUPERSEDED",
];

/* ------------------------- fail-closed errors ------------------------- */

/** Programmer/operator errors: loud, no journal write, no mutation. */
export class GateError extends Error {
  readonly code:
    | "identity-invalid"
    | "unknown-proposal"
    | "proposal-malformed"
    | "verdict-invalid"
    | "clock-invalid"
    | "context-invalid";
  constructor(
    code: GateError["code"],
    message: string,
  ) {
    super("approval-gate[" + code + "]: " + message);
    this.name = "GateError";
    this.code = code;
  }
}

/* ------------------------- small pure helpers ------------------------- */

function sha256Hex(bytes: string): string {
  return createHash("sha256").update(bytes, "utf8").digest("hex");
}

/**
 * Canonical bytes for digesting. Strings are already bytes: the canonical
 * form of a byte string is itself (no JSON quoting), so
 * sha256(canonical(sourceBytesNow)) is the hash of the exact source bytes
 * and one mutated byte changes the digest. Non-strings go through the
 * existing sorted-key canonicalizer (src/lib/ping/dev-signer.ts).
 *
 * T1 reconciliation note: the proposer MUST compute proposed_digest as
 * sha256(canonical(patch)) and base_digest as sha256(sourceBytes) with
 * this same rule, or verification fails closed to DENIED/STALE_SUPERSEDED.
 */
export function canonicalBytes(value: unknown): string {
  if (typeof value === "string") return value;
  return canonicalizeJson(value);
}

function isWellFormedIdentity(v: unknown): v is string {
  return (
    typeof v === "string" &&
    v.trim().length > 0 &&
    v.length <= 256 &&
    !/[\u0000-\u001f\u007f]/.test(v)
  );
}

function isProposalStatus(v: unknown): v is ProposalStatus {
  return (
    v === "PROPOSED" ||
    v === "APPROVED" ||
    v === "DENIED" ||
    v === "EXPIRED" ||
    v === "SUPERSEDED"
  );
}

/** Structural validation of the queue record. Fail-closed: throw. */
function asProposalRecord(v: unknown, proposal_id: string): ProposalRecord {
  if (typeof v !== "object" || v === null) {
    throw new GateError("proposal-malformed", "queue returned a non-object record.");
  }
  const r = v as Record<string, unknown>;
  if (r.proposal_id !== proposal_id) {
    throw new GateError(
      "proposal-malformed",
      "queue record id does not match the requested proposal_id.",
    );
  }
  if (!isProposalStatus(r.status)) {
    throw new GateError(
      "proposal-malformed",
      "record has no recognizable proposal status.",
    );
  }
  return v as ProposalRecord;
}

function evidenceRefsOf(p: ProposalRecord): string[] {
  const refs = (p as unknown as { evidence_refs?: unknown }).evidence_refs;
  if (!Array.isArray(refs)) return [];
  return refs.filter(
    (r): r is string => typeof r === "string" && r.trim().length > 0,
  );
}

function minEvidenceRefsOf(p: ProposalRecord): number {
  const n = (p as unknown as { min_evidence_refs?: unknown }).min_evidence_refs;
  if (typeof n === "number" && Number.isFinite(n) && n >= 0) return Math.floor(n);
  return 1;
}

function expiresAtOf(p: ProposalRecord): number {
  const n = (p as unknown as { expires_at?: unknown }).expires_at;
  return typeof n === "number" && Number.isFinite(n) ? n : NaN;
}

function requiredCapabilityOf(p: ProposalRecord): string | null {
  const c = (p as unknown as { required_capability?: unknown }).required_capability;
  return typeof c === "string" && c.trim().length > 0 ? c : null;
}

function proposedDigestOf(p: ProposalRecord): string | null {
  const d = (p as unknown as { proposed_digest?: unknown }).proposed_digest;
  return typeof d === "string" && /^[0-9a-f]{64}$/.test(d) ? d : null;
}

function baseDigestOf(p: ProposalRecord): string | null {
  const d = (p as unknown as { base_digest?: unknown }).base_digest;
  return typeof d === "string" && /^[0-9a-f]{64}$/.test(d) ? d : null;
}

function targetObjectIdOf(p: ProposalRecord): string | null {
  const t = (p as unknown as { target_object_id?: unknown }).target_object_id;
  return typeof t === "string" && t.length > 0 ? t : null;
}

function patchOf(p: ProposalRecord): unknown {
  return (p as unknown as { patch?: unknown }).patch;
}

/* ------------------------- injectable dependencies ------------------------- */

/**
 * Everything the gate needs from the outside world, as one seam. The
 * exported decideApproval wires the real modules; decideApprovalWith
 * takes explicit deps so unit tests never touch the filesystem or the
 * (not yet landed) teammate modules.
 */
export interface GateStores {
  getProposal: (proposal_id: string) => unknown;
  markProposal: (
    proposal_id: string,
    status: ProposalStatus,
    decided_at_ms: number,
    decided_by: string,
  ) => void;
  appendApprovalEvent: (journalPath: string, event: ApprovalJournalPayload) => string;
  readObjectState: (objectId: string) => unknown;
  applyTransition: (req: GateTransitionRequest, ctx: GateTransitionContext) => void;
}

/**
 * The payload the gate hands to T3's appendApprovalEvent. The journal
 * owns event-id generation (payload in, id out), the same pattern as
 * the existing appendOwnerEvent. If T3's ApprovalJournalEvent carries
 * extra required fields, this payload must grow to match; the gate's
 * unit tests pin exactly what is sent.
 */
export interface ApprovalJournalPayload {
  event_type: ApprovalEventType;
  proposal_id: string;
  proposed_digest: string | null;
  decided_at_ms: number;
  decider_identity: string;
  evidence_refs: string[];
  reason?: string;
  pre_hash?: string | null;
  post_hash?: string | null;
  base_digest_expected?: string | null;
  base_digest_actual?: string;
}

function journal(
  stores: GateStores,
  journalPath: string,
  event: ApprovalJournalPayload,
): string {
  return stores.appendApprovalEvent(journalPath, event);
}

function baseJournalEvent(
  type: ApprovalEventType,
  p: ProposalRecord,
  ctx: ApprovalContext,
  nowMs: number,
): ApprovalJournalPayload {
  return {
    event_type: type,
    proposal_id: p.proposal_id,
    proposed_digest: proposedDigestOf(p),
    decided_at_ms: nowMs,
    decider_identity: ctx.deciderIdentity,
    evidence_refs: evidenceRefsOf(p),
  };
}

/* ------------------------- the decision ------------------------- */

/**
 * Core decision logic with injected stores. See the module docstring for
 * the verification order. Never throws for proposal-lifecycle reasons;
 * throws GateError only for fail-closed programmer/operator errors
 * (bad identity, unknown proposal, malformed record, bad clock), which
 * perform no journal write and no mutation.
 */
export function decideApprovalWith(
  stores: GateStores,
  proposal_id: string,
  verdict: ApprovalVerdict,
  ctx: ApprovalContext,
  nowMs: number,
): ApprovalResult {
  // 0. Fail-closed input validation. Loud, no journal, no mutation.
  if (!isWellFormedIdentity(ctx.deciderIdentity)) {
    throw new GateError("identity-invalid", "deciderIdentity is missing or ill-formed.");
  }
  if (!Array.isArray(ctx.deciderCapabilities)) {
    throw new GateError("context-invalid", "deciderCapabilities must be an array.");
  }
  if (typeof ctx.journalPath !== "string" || ctx.journalPath.length === 0) {
    throw new GateError("context-invalid", "journalPath must be a non-empty string.");
  }
  if (verdict !== "APPROVE" && verdict !== "DENY") {
    throw new GateError("verdict-invalid", "verdict must be APPROVE or DENY.");
  }
  if (typeof nowMs !== "number" || !Number.isFinite(nowMs)) {
    throw new GateError("clock-invalid", "nowMs must be a finite number.");
  }

  const raw = stores.getProposal(proposal_id);
  if (raw === undefined || raw === null) {
    throw new GateError("unknown-proposal", "no proposal with id '" + proposal_id + "'.");
  }
  const p = asProposalRecord(raw, proposal_id);

  // 0 (evaluated first). Double-decision guard: exactly one terminal
  // decision owns the transition. A terminal lifecycle is immutable, so
  // this runs before capability/digest/base checks: no second decision
  // may rewrite it, even one whose checks would fail. No journal write,
  // no mutation.
  if (p.status !== "PROPOSED") {
    return {
      outcome: "ALREADY_DECIDED",
      preHash: null,
      postHash: null,
      journalEventId: "",
    };
  }

  const expiresAt = expiresAtOf(p);
  const expired = !Number.isFinite(expiresAt) || nowMs > expiresAt;

  // DENY path. Marks lifecycle only; the target object is untouched and
  // no compensating object state is written: nothing happened.
  if (verdict === "DENY") {
    if (expired) {
      stores.markProposal(p.proposal_id, "EXPIRED", nowMs, GATE_SYSTEM_IDENTITY);
      const eventId = journal(stores, ctx.journalPath, {
        ...baseJournalEvent("APPROVAL_EXPIRED", p, ctx, nowMs),
        reason: Number.isFinite(expiresAt) ? "expired" : "expires-at-missing-or-invalid",
      });
      return { outcome: "EXPIRED", preHash: null, postHash: null, journalEventId: eventId };
    }
    stores.markProposal(p.proposal_id, "DENIED", nowMs, ctx.deciderIdentity);
    const eventId = journal(stores, ctx.journalPath, {
      ...baseJournalEvent("APPROVAL_DENIED", p, ctx, nowMs),
      reason: "owner-denied",
    });
    return {
      outcome: "DENIED",
      preHash: null,
      postHash: null,
      journalEventId: eventId,
      reason: "owner-denied",
    };
  }

  // APPROVE path. Authorization strictly BEFORE effect.
  const deny = (
    reason: "capability-missing" | "digest-invalid" | "target-unresolvable" | "evidence-missing",
  ): ApprovalResult => {
    stores.markProposal(p.proposal_id, "DENIED", nowMs, ctx.deciderIdentity);
    const eventId = journal(stores, ctx.journalPath, {
      ...baseJournalEvent("APPROVAL_DENIED", p, ctx, nowMs),
      reason,
    });
    return {
      outcome: "DENIED",
      preHash: null,
      postHash: null,
      journalEventId: eventId,
      reason,
    };
  };

  // 2. Capability. The decider must hold what the proposal requires.
  const required = requiredCapabilityOf(p);
  if (required === null || !ctx.deciderCapabilities.includes(required)) {
    return deny("capability-missing");
  }

  // 3. Exact digest. Approval of proposal X MUST NOT authorize a modified
  // X: one byte changes, the digest changes, the old approval is invalid.
  const want = proposedDigestOf(p);
  if (want === null || sha256Hex(canonicalBytes(patchOf(p))) !== want) {
    return deny("digest-invalid");
  }

  // 4. Base state (TOCTOU guard). The proposal was generated against
  // object state A; if the object moved A -> B, approving the A-proposal
  // must NOT silently apply to B. Distinct from DENIED.
  if (typeof ctx.sourceBytesNow !== "string") {
    throw new GateError("context-invalid", "sourceBytesNow must be a string.");
  }
  const base = baseDigestOf(p);
  if (base === null || sha256Hex(canonicalBytes(ctx.sourceBytesNow)) !== base) {
    stores.markProposal(p.proposal_id, "SUPERSEDED", nowMs, GATE_SYSTEM_IDENTITY);
    const eventId = journal(stores, ctx.journalPath, {
      ...baseJournalEvent("APPROVAL_SUPERSEDED", p, ctx, nowMs),
      reason: "base-state-moved",
      base_digest_expected: base,
      base_digest_actual: sha256Hex(canonicalBytes(ctx.sourceBytesNow)),
    });
    return {
      outcome: "STALE_SUPERSEDED",
      preHash: null,
      postHash: null,
      journalEventId: eventId,
      reason: "base-state-moved",
    };
  }

  // 6. Expiry. Reject-by-default: silence is never approval. A proposal
  // with no usable expires_at is treated as expired (an unbounded
  // authorization window is fail-closed to EXPIRED, never APPROVED).
  if (expired) {
    stores.markProposal(p.proposal_id, "EXPIRED", nowMs, GATE_SYSTEM_IDENTITY);
    const eventId = journal(stores, ctx.journalPath, {
      ...baseJournalEvent("APPROVAL_EXPIRED", p, ctx, nowMs),
      reason: Number.isFinite(expiresAt) ? "expired" : "expires-at-missing-or-invalid",
    });
    return { outcome: "EXPIRED", preHash: null, postHash: null, journalEventId: eventId };
  }

  // 7. Target resolves. Validate now, apply later: a GateTransitionError
  // becomes DENIED with zero mutation, never a half-apply.
  const targetObjectId = targetObjectIdOf(p);
  if (targetObjectId === null) {
    return deny("target-unresolvable");
  }
  try {
    resolveGateTransitionTarget(patchOf(p), targetObjectId);
  } catch (err) {
    if (err instanceof GateTransitionError) return deny("target-unresolvable");
    throw err;
  }

  // 8. Evidence meets the proposal's requirements.
  const refs = evidenceRefsOf(p);
  if (refs.length < minEvidenceRefsOf(p)) {
    return deny("evidence-missing");
  }

  // 9. The canonical transition. preHash over canonical object bytes
  // before, apply through the EXISTING owner-events path, postHash after,
  // then mark APPROVED and journal APPROVAL_APPROVED with identity,
  // evidence refs, and pre/post hashes. If applyTransition throws (store
  // failure), nothing is marked and nothing is journaled: loud failure,
  // operator-visible, no phantom approval.
  const preHash = sha256Hex(canonicalizeJson(stores.readObjectState(targetObjectId)));
  stores.applyTransition(
    {
      proposalId: p.proposal_id,
      proposedDigest: want,
      targetObjectId,
      patch: patchOf(p),
      evidenceRefs: refs,
    },
    { deciderIdentity: ctx.deciderIdentity, decidedAtMs: nowMs },
  );
  const postHash = sha256Hex(canonicalizeJson(stores.readObjectState(targetObjectId)));

  stores.markProposal(p.proposal_id, "APPROVED", nowMs, ctx.deciderIdentity);
  const eventId = journal(stores, ctx.journalPath, {
    ...baseJournalEvent("APPROVAL_APPROVED", p, ctx, nowMs),
    pre_hash: preHash,
    post_hash: postHash,
  });
  return {
    outcome: "APPLIED",
    preHash,
    postHash,
    journalEventId: eventId,
  };
}

/**
 * The contract entry point. Wires the real teammate modules
 * (./queue, ./journal) and the existing object-transition path.
 */
export function decideApproval(
  proposal_id: string,
  verdict: ApprovalVerdict,
  ctx: ApprovalContext,
  nowMs: number,
): ApprovalResult {
  return decideApprovalWith(
    {
      getProposal,
      markProposal,
      appendApprovalEvent,
      readObjectState: readGateObjectState,
      applyTransition: applyGateTransition,
    },
    proposal_id,
    verdict,
    ctx,
    nowMs,
  );
}
