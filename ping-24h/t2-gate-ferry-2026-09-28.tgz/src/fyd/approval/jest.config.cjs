/**
 * Jest config for the Phase 1 approval door (src/fyd/approval).
 * Scoped to this gate's tests; sibling lanes own their own test scope.
 * Run with: npx jest --config src/fyd/approval/jest.config.cjs
 *
 * moduleNameMapper redirects gate.ts's teammate value-imports ('./queue',
 * './journal') to the test doubles in __tests__/doubles/. No mapping is
 * needed for './types': it is imported type-only everywhere, so ts-jest
 * elides it at runtime. DELETE these mappings when T1's queue.ts and T3's
 * journal.ts land; the suite then exercises the real modules.
 *
 * diagnostics:false is TEMPORARY: T1/T3 files are absent, so a full
 * typecheck cannot resolve './queue'/'./journal'/'./types' yet. A
 * separate tsc pass with throwaway stubs validates this file's types
 * (see the gate commit notes); re-enable diagnostics once the
 * teammate files land.
 */
module.exports = {
  testEnvironment: "node",
  rootDir: "../../..",
  testMatch: ["<rootDir>/src/fyd/approval/__tests__/*.test.ts"],
  moduleNameMapper: {
    "^\\./queue$": "<rootDir>/src/fyd/approval/__tests__/doubles/queue.ts",
    "^\\./journal$": "<rootDir>/src/fyd/approval/__tests__/doubles/journal.ts",
  },
  transform: {
    "^.+\\.tsx?$": [
      "ts-jest",
      {
        diagnostics: false,
        tsconfig: {
          target: "ES2022",
          module: "commonjs",
          moduleResolution: "node",
          esModuleInterop: true,
          strict: true,
          skipLibCheck: true,
        },
      },
    ],
  },
};
