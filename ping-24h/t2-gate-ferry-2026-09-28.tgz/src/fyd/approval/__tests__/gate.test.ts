/**
 * Unit tests for the Phase 1 approval door (../gate.ts).
 *
 * Strategy: decideApprovalWith with injected stores. Queue + journal are
 * the committed test doubles in ./doubles (deleted when T1's queue.ts and
 * T3's journal.ts land); the object transition uses the REAL path
 * (applyGateTransition -> appendOwnerEvent -> projectOwnerState) with
 * FYD_OWNER_DIR pointed at a fresh temp dir per test, so "zero mutation"
 * assertions observe the actual owner event log.
 *
 * Clock is a fixed constant; no wall-clock dependence anywhere. Every
 * digest is computed in-test with node:crypto over the same canonical
 * rule the gate documents, so the tests pin the digest contract.
 */

import { createHash } from "node:crypto";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { decideApprovalWith, canonicalBytes, GateError } from "../gate";
import {
  applyGateTransition,
  readGateObjectState,
} from "../apply-owner-event";
import {
  readOwnerEvents,
  projectOwnerState,
} from "../../object/owner-events";
import {
  getProposal,
  markProposal,
  __resetQueue,
  __seedProposal,
  __getRecord,
  type TestProposal,
} from "./doubles/queue";
import {
  appendApprovalEvent,
  __resetJournal,
  __journalEvents,
} from "./doubles/journal";

const NOW = 1780000000000; // fixed clock, ms
const OBJECT_ID = "biz-test-001";
const CAP = "owner.correct-fact";
const SOURCE_BYTES = JSON.stringify({
  objectId: OBJECT_ID,
  phone: "+1-970-555-0000",
});

function sha256(s: string): string {
  return createHash("sha256").update(s, "utf8").digest("hex");
}

function makePatch(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    kind: "fact_correction",
    objectId: OBJECT_ID,
    field: "phone",
    op: "CORRECT",
    value: "+1-970-555-0100",
    sourceValueSeen: "+1-970-555-0000",
    ...overrides,
  };
}

function draftProposal(opts: {
  patch?: Record<string, unknown>;
  sourceBytes?: string;
  proposalId?: string;
  top?: Record<string, unknown>;
} = {}): { proposal: TestProposal; sourceBytes: string } {
  const patch = opts.patch ?? makePatch();
  const sourceBytes = opts.sourceBytes ?? SOURCE_BYTES;
  const proposal: TestProposal = {
    proposal_id: opts.proposalId ?? "prop-001",
    status: "PROPOSED",
    patch,
    proposed_digest: sha256(canonicalBytes(patch)),
    base_digest: sha256(sourceBytes),
    required_capability: CAP,
    target_object_id: OBJECT_ID,
    evidence_refs: ["evidence:packet-1"],
    min_evidence_refs: 1,
    expires_at: NOW + 3600_000,
  };
  if (opts.top) Object.assign(proposal, opts.top);
  return { proposal, sourceBytes };
}

function makeCtx(overrides: Record<string, unknown> = {}) {
  return {
    sourceBytesNow: SOURCE_BYTES,
    deciderIdentity: "owner:nolan",
    deciderCapabilities: [CAP],
    journalPath: path.join(ownerDir, "approvals.jsonl"),
    ...overrides,
  };
}

const stores = {
  getProposal,
  markProposal,
  appendApprovalEvent,
  readObjectState: readGateObjectState,
  applyTransition: applyGateTransition,
};

let ownerDir: string;

beforeEach(() => {
  __resetQueue();
  __resetJournal();
  ownerDir = fs.mkdtempSync(path.join(os.tmpdir(), "gate-test-"));
  process.env.FYD_OWNER_DIR = ownerDir;
});

afterEach(() => {
  delete process.env.FYD_OWNER_DIR;
  fs.rmSync(ownerDir, { recursive: true, force: true });
});

function ownerFiles(): string[] {
  return fs.readdirSync(ownerDir);
}

test("happy-path approve: applies the transition, journals APPROVAL_APPROVED", () => {
  const { proposal } = draftProposal();
  __seedProposal(proposal);
  const preState = projectOwnerState(OBJECT_ID);
  const expectedPreHash = sha256(canonicalBytes(preState));

  const res = decideApprovalWith(stores, "prop-001", "APPROVE", makeCtx(), NOW);

  expect(res.outcome).toBe("APPLIED");
  expect(res.preHash).toBe(expectedPreHash);
  expect(res.postHash).toMatch(/^[0-9a-f]{64}$/);
  expect(res.postHash).not.toBe(res.preHash);
  expect(res.journalEventId).toBe("jev-test-0001");
  expect(res.reason).toBeUndefined();

  // Proposal lifecycle moved exactly once.
  expect(__getRecord("prop-001")!.status).toBe("APPROVED");

  // Journal carries identity, evidence refs, and pre/post hashes.
  const evs = __journalEvents();
  expect(evs).toHaveLength(1);
  expect(evs[0].event_type).toBe("APPROVAL_APPROVED");
  expect(evs[0].proposal_id).toBe("prop-001");
  expect(evs[0].decider_identity).toBe("owner:nolan");
  expect(evs[0].evidence_refs).toEqual(["evidence:packet-1"]);
  expect(evs[0].pre_hash).toBe(res.preHash);
  expect(evs[0].post_hash).toBe(res.postHash);

  // The object REALLY changed through the existing owner-events path.
  const events = readOwnerEvents(OBJECT_ID);
  expect(events).toHaveLength(1);
  expect(events[0].type).toBe("owner.corrected-fact");
  expect(events[0].target).toBe("contact:phone");
  expect(events[0].actor).toEqual({
    kind: "owner",
    identityId: "owner:nolan",
    label: "owner:nolan",
  });
  const after = projectOwnerState(OBJECT_ID);
  expect(after.fieldCorrections["phone"].ownerValue).toBe("+1-970-555-0100");
  // postHash independently re-verified against a fresh fold of the log.
  expect(res.postHash).toBe(sha256(canonicalBytes(after)));
});

test("happy-path approve: CONFIRM op flows through the same real path", () => {
  const { proposal } = draftProposal({
    patch: makePatch({ op: "CONFIRM", value: null }),
  });
  __seedProposal(proposal);
  const res = decideApprovalWith(stores, "prop-001", "APPROVE", makeCtx(), NOW);
  expect(res.outcome).toBe("APPLIED");
  const events = readOwnerEvents(OBJECT_ID);
  expect(events).toHaveLength(1);
  expect(events[0].type).toBe("owner.confirmed-fact");
});

test("digest tamper: one-byte patch mutation => DENIED, zero mutation", () => {
  const { proposal } = draftProposal();
  // Mutate ONE byte of the patch after the digest was pinned.
  const tampered = {
    ...(proposal.patch as Record<string, unknown>),
    value: "+1-970-555-0101",
  };
  __seedProposal({ ...proposal, patch: tampered });

  const res = decideApprovalWith(stores, "prop-001", "APPROVE", makeCtx(), NOW);

  expect(res.outcome).toBe("DENIED");
  expect(res.reason).toBe("digest-invalid");
  expect(res.preHash).toBeNull();
  expect(res.postHash).toBeNull();
  expect(__getRecord("prop-001")!.status).toBe("DENIED");
  const evs = __journalEvents();
  expect(evs).toHaveLength(1);
  expect(evs[0].event_type).toBe("APPROVAL_DENIED");
  expect(evs[0].reason).toBe("digest-invalid");
  // Zero mutation: no owner log file was created.
  expect(ownerFiles()).toHaveLength(0);
});

test("missing digest => DENIED, zero mutation", () => {
  const { proposal } = draftProposal({ top: { proposed_digest: null } });
  __seedProposal(proposal);
  const res = decideApprovalWith(stores, "prop-001", "APPROVE", makeCtx(), NOW);
  expect(res.outcome).toBe("DENIED");
  expect(res.reason).toBe("digest-invalid");
  expect(ownerFiles()).toHaveLength(0);
});

test("stale base: sourceBytesNow moved => STALE_SUPERSEDED, zero mutation", () => {
  const { proposal } = draftProposal();
  __seedProposal(proposal);
  const moved = JSON.stringify({ objectId: OBJECT_ID, phone: "+1-970-555-9999" });

  const res = decideApprovalWith(
    stores,
    "prop-001",
    "APPROVE",
    makeCtx({ sourceBytesNow: moved }),
    NOW,
  );

  expect(res.outcome).toBe("STALE_SUPERSEDED");
  expect(res.reason).toBe("base-state-moved");
  expect(res.preHash).toBeNull();
  expect(res.postHash).toBeNull();
  expect(__getRecord("prop-001")!.status).toBe("SUPERSEDED");
  const evs = __journalEvents();
  expect(evs).toHaveLength(1);
  expect(evs[0].event_type).toBe("APPROVAL_SUPERSEDED");
  expect(evs[0].base_digest_expected).toBe(proposal.base_digest);
  expect(evs[0].base_digest_actual).toBe(sha256(moved));
  // The A-proposal was NOT silently applied to state B.
  expect(ownerFiles()).toHaveLength(0);
});

test("double decision: second call => ALREADY_DECIDED, single canonical mutation", () => {
  const { proposal } = draftProposal();
  __seedProposal(proposal);

  const first = decideApprovalWith(stores, "prop-001", "APPROVE", makeCtx(), NOW);
  expect(first.outcome).toBe("APPLIED");

  const second = decideApprovalWith(stores, "prop-001", "APPROVE", makeCtx(), NOW + 5000);
  expect(second.outcome).toBe("ALREADY_DECIDED");
  expect(second.journalEventId).toBe("");
  expect(second.preHash).toBeNull();
  expect(second.postHash).toBeNull();

  // No second journal write, no second transition: exactly one mutation.
  expect(__journalEvents()).toHaveLength(1);
  expect(readOwnerEvents(OBJECT_ID)).toHaveLength(1);
  expect(__getRecord("prop-001")!.status).toBe("APPROVED");

  // A DENY after APPROVED is also ALREADY_DECIDED, not a lifecycle rewrite.
  const third = decideApprovalWith(stores, "prop-001", "DENY", makeCtx(), NOW + 9000);
  expect(third.outcome).toBe("ALREADY_DECIDED");
  expect(__journalEvents()).toHaveLength(1);
  expect(__getRecord("prop-001")!.status).toBe("APPROVED");
});

test("timeout: nowMs past expires_at => EXPIRED, zero mutation, distinct from DENIED", () => {
  const { proposal } = draftProposal();
  __seedProposal(proposal);

  const res = decideApprovalWith(
    stores,
    "prop-001",
    "APPROVE",
    makeCtx(),
    NOW + 3600_000 + 1,
  );

  expect(res.outcome).toBe("EXPIRED");
  expect(__getRecord("prop-001")!.status).toBe("EXPIRED");
  const evs = __journalEvents();
  expect(evs).toHaveLength(1);
  expect(evs[0].event_type).toBe("APPROVAL_EXPIRED");
  expect(evs[0].reason).toBe("expired");
  expect(ownerFiles()).toHaveLength(0);

  // Boundary: nowMs === expires_at is still inside the window.
  const p2 = draftProposal({ proposalId: "prop-002" });
  __seedProposal(p2.proposal);
  const atDeadline = decideApprovalWith(
    stores,
    "prop-002",
    "APPROVE",
    makeCtx(),
    NOW + 3600_000,
  );
  expect(atDeadline.outcome).toBe("APPLIED");
});

test("deny: zero target mutation, lifecycle recorded", () => {
  const { proposal } = draftProposal();
  __seedProposal(proposal);

  const res = decideApprovalWith(stores, "prop-001", "DENY", makeCtx(), NOW);

  expect(res.outcome).toBe("DENIED");
  expect(res.reason).toBe("owner-denied");
  expect(res.preHash).toBeNull();
  expect(res.postHash).toBeNull();
  expect(__getRecord("prop-001")!.status).toBe("DENIED");
  const evs = __journalEvents();
  expect(evs).toHaveLength(1);
  expect(evs[0].event_type).toBe("APPROVAL_DENIED");
  expect(evs[0].reason).toBe("owner-denied");
  expect(evs[0].decider_identity).toBe("owner:nolan");
  expect(evs[0].evidence_refs).toEqual(["evidence:packet-1"]);
  // Nothing happened to the object: no compensating state written.
  expect(ownerFiles()).toHaveLength(0);
});

test("deny on an expired proposal => EXPIRED (expiry evaluated first)", () => {
  const { proposal } = draftProposal();
  __seedProposal(proposal);
  const res = decideApprovalWith(
    stores,
    "prop-001",
    "DENY",
    makeCtx(),
    NOW + 3600_000 + 1,
  );
  expect(res.outcome).toBe("EXPIRED");
  expect(__getRecord("prop-001")!.status).toBe("EXPIRED");
  expect(__journalEvents()[0].event_type).toBe("APPROVAL_EXPIRED");
});

test("capability-missing => DENIED, zero mutation", () => {
  const { proposal } = draftProposal();
  __seedProposal(proposal);
  const res = decideApprovalWith(
    stores,
    "prop-001",
    "APPROVE",
    makeCtx({ deciderCapabilities: ["owner.view-only"] }),
    NOW,
  );
  expect(res.outcome).toBe("DENIED");
  expect(res.reason).toBe("capability-missing");
  expect(__journalEvents()[0].reason).toBe("capability-missing");
  expect(ownerFiles()).toHaveLength(0);
});

test("evidence-missing => DENIED, zero mutation", () => {
  const { proposal } = draftProposal({ top: { evidence_refs: [] } });
  __seedProposal(proposal);
  const res = decideApprovalWith(stores, "prop-001", "APPROVE", makeCtx(), NOW);
  expect(res.outcome).toBe("DENIED");
  expect(res.reason).toBe("evidence-missing");
  expect(ownerFiles()).toHaveLength(0);
});

test("target-unresolvable => DENIED, zero mutation", () => {
  // Valid digest over a patch the gate cannot apply (unsupported field).
  const { proposal } = draftProposal({
    patch: makePatch({ field: "address", op: "CORRECT" }),
  });
  __seedProposal(proposal);
  const res = decideApprovalWith(stores, "prop-001", "APPROVE", makeCtx(), NOW);
  expect(res.outcome).toBe("DENIED");
  expect(res.reason).toBe("target-unresolvable");
  expect(__journalEvents()[0].reason).toBe("target-unresolvable");
  expect(ownerFiles()).toHaveLength(0);
});

test("ill-formed identity fails closed: throws, no journal, no mutation", () => {
  const { proposal } = draftProposal();
  __seedProposal(proposal);
  expect(() =>
    decideApprovalWith(stores, "prop-001", "APPROVE", makeCtx({ deciderIdentity: "   " }), NOW),
  ).toThrow(GateError);
  expect(__journalEvents()).toHaveLength(0);
  expect(ownerFiles()).toHaveLength(0);
  expect(__getRecord("prop-001")!.status).toBe("PROPOSED");
});

test("unknown proposal fails closed: throws, no journal, no mutation", () => {
  expect(() =>
    decideApprovalWith(stores, "prop-nope", "APPROVE", makeCtx(), NOW),
  ).toThrow(GateError);
  expect(__journalEvents()).toHaveLength(0);
  expect(ownerFiles()).toHaveLength(0);
});

test("missing expires_at fails closed to EXPIRED (no unbounded authorization)", () => {
  const { proposal } = draftProposal({ top: { expires_at: null } });
  __seedProposal(proposal);
  const res = decideApprovalWith(stores, "prop-001", "APPROVE", makeCtx(), NOW);
  expect(res.outcome).toBe("EXPIRED");
  expect(__journalEvents()[0].reason).toBe("expires-at-missing-or-invalid");
  expect(ownerFiles()).toHaveLength(0);
});
