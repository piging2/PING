/**
 * TEST DOUBLE for T3's src/fyd/approval/journal.ts.
 *
 * In-memory journal implementing the payload-in/id-out contract the
 * gate documents (see ApprovalJournalPayload in ../gate.ts). DELETE this
 * file (and the moduleNameMapper entry in jest.config.cjs) when T3's
 * real journal.ts lands; the tests then run against the real journal.
 */

import type { ApprovalJournalPayload } from "../../gate";

export interface TestJournalEvent extends ApprovalJournalPayload {
  journal_id: string;
  journal_path: string;
}

const events: TestJournalEvent[] = [];
let seq = 0;

export function __resetJournal(): void {
  events.length = 0;
  seq = 0;
}

export function __journalEvents(): TestJournalEvent[] {
  return [...events];
}

export function appendApprovalEvent(
  journalPath: string,
  event: ApprovalJournalPayload,
): string {
  seq += 1;
  const journal_id = "jev-test-" + String(seq).padStart(4, "0");
  events.push({ journal_id, journal_path: journalPath, ...event });
  return journal_id;
}
