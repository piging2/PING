/**
 * TEST DOUBLE for T1's src/fyd/approval/queue.ts.
 *
 * In-memory proposal store implementing the expected queue signatures
 * documented in gate.ts. DELETE this file (and the moduleNameMapper entry
 * in jest.config.cjs) when T1's real queue.ts lands; the tests then run
 * against the real store.
 */

export interface TestProposal {
  proposal_id: string;
  status: string;
  patch: unknown;
  proposed_digest?: string | null;
  base_digest?: string | null;
  required_capability?: string | null;
  target_object_id?: string | null;
  evidence_refs?: unknown;
  min_evidence_refs?: unknown;
  expires_at?: unknown;
}

export interface MarkedDecision {
  proposal_id: string;
  status: string;
  decided_at_ms: number;
  decided_by: string;
}

const store = new Map<string, TestProposal>();
const marks: MarkedDecision[] = [];

export function __resetQueue(): void {
  store.clear();
  marks.length = 0;
}

export function __seedProposal(p: TestProposal): void {
  store.set(p.proposal_id, { ...p });
}

/** Raw record for assertions (bypasses the copy semantics of getProposal). */
export function __getRecord(proposal_id: string): TestProposal | undefined {
  return store.get(proposal_id);
}

export function __getMarks(): MarkedDecision[] {
  return [...marks];
}

export function getProposal(proposal_id: string): TestProposal | undefined {
  const p = store.get(proposal_id);
  return p === undefined ? undefined : { ...p };
}

export function markProposal(
  proposal_id: string,
  status: string,
  decided_at_ms: number,
  decided_by: string,
): void {
  const p = store.get(proposal_id);
  if (!p) throw new Error("test queue: unknown proposal '" + proposal_id + "'");
  store.set(proposal_id, { ...p, status });
  marks.push({ proposal_id, status, decided_at_ms, decided_by });
}
